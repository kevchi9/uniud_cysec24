<?php 
// used to send username through ajax request
session_start();
echo $_SESSION['username'];
?>