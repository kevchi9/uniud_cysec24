<?php 



//    $file = fopen("/opt/lampp/htdocs/passVal/".$fn.".record","w");
//    echo fwrite($file,$str);
//    fclose($file);
?>
