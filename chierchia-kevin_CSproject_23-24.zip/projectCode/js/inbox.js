document.getElementById("cancel_button").onclick = function () {
    location.href = "index.php";
}